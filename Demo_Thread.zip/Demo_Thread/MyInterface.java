interface MyInterface
{
	public void show();
	
}