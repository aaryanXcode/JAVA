class Demo extends Class1
{
	public Demo()
	{
		start();
	}

	public void show()	
	{
		System.out.println("Hello From Demo");
	}
	public static void main(String a[])
	{
		new Demo();
	}
}