class Demo
{
	public static void main(String a[])
	{
		System.out.println("DD");
	}
}