interface Shape
{
	double pi=3.14;
	public int area();
	public int perimeter();
	public void show();
}